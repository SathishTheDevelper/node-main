var admin_baseurl = '/api/v1/admin/';

module.exports = (app) => {
  //Admin Panel
  app.use(admin_baseurl,require("../controller/admin/admin_login"));
  app.use(admin_baseurl+'mastersettings', require("../controller/admin/master_settings"));
}