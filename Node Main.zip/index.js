const express = require('express');
const bodyParser = require('body-parser');
const dbConnect = require("./config/db");
const { notFound, errorHandler } = require('./middlewares/errorHandler');
const app = express();
const dotenv = require('dotenv').config();
const PORT = process.env.PORT || 6000;
const cookieParser = require('cookie-parser');
const morgon = require('morgan');
const cors = require('cors');

//DataBase Connection
dbConnect();
app.use(morgon('dev'));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
//Routes
require("./routes/")(app);
//Error Handler
app.use(notFound);
app.use(errorHandler);

//Create Server
app.listen(PORT, () => {
  console.log(`Server is running at post ${PORT}`);
})