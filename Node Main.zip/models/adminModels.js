const mongoose = require("mongoose");
const bcrypt = require("bcrypt");

var adminSchema = new mongoose.Schema(
  {
    name: {
      type: String,
     
    },
    companyname: {
      type: String,
      
    },
    email: {
      type: String,
     
    },
    phone: {
      type: String,
      
    },
    password: {
      type: String,
      
    },
    role: {
      type: String,
      require: true,
      default: "admin",
      trim: true,
    },
    isblocked: {
      type: Boolean,
      default: false,
    },
    companycode: {
      type: String,
    },
    status: {
      type: String,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);




module.exports = mongoose.model("Admin", adminSchema);
