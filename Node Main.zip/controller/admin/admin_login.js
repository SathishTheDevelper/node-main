const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const asyncHandler = require("express-async-handler");
const { admin } = require('../../utils/schemaMaster');
const { generateToken } = require("../../config/jwtToken");
const { success, successToken } = require("../../utils/response");
const sendMail = require('../../utils/sendMail');
const { register} = require('../../utils/email_template');
const mongoose = require('mongoose');
const crud_service = require('../../utils/crud_service');
const crud = new crud_service();
//create admin
router.post('/register', asyncHandler(async (req, res) => {
  const check_phone = await crud.getOneDocument(admin,{ phone_number: req?.body?.phone_number },{},{});
  const check_email = await crud.getOneDocument(admin,{ email_id: req?.body?.email_id },{},{});
  if (check_phone) throw new Error('Phone Number Already Taken!');
  if (check_email) throw new Error("Email Address Already Taken!");
  const salt = bcrypt.genSaltSync(10);
  req.body.password = await bcrypt.hash(req?.body?.password, salt);
  req.body.company_code = new mongoose.mongo.ObjectId();
  try {
    const create = await crud.insertOne(admin, req.body);
    if (create) {
      const options = {
        email: req?.body?.email_id,
        subject: "Ecommerce Admin Register",
        message: register(create?.name),
      };
      sendMail(options);
      successToken(res, 201, true, "Register Successfully",create,generateToken(create?._id));
    } else {
      throw new Error("Register Failed!");
    }
  } catch (error) {
    throw new Error(error);
  }
}))
//admin login
router.post('/login', asyncHandler(async (req, res) => {
  const { phone_number, password } = req.body;
  try {
    const find_admin = await crud.getOneDocument(admin, { phone_number },{},{});
    const password_match = async (password) => {
      return await bcrypt.compare(password, find_admin?.password);
    }
    if (find_admin && await password_match(password)) {
      successToken(res, 200, true, "Login Successfully",find_admin,generateToken(find_admin?._id));
    } else {
      throw new Error("Invalid Username Or Password!")
    } 
  } catch (error) {
    throw new Error(error);
  }
}))



module.exports = router;