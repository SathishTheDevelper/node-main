const admin = require('../models/adminModels');
const logs = require("../models/logsModels");
const mongoose = require("mongoose");
const uniqid = require('uniqid');
const asyncHandler = require('express-async-handler');
const { success, successToken } = require('../utils/response');
const { generateToken } = require("../config/jwtToken");
const crud_service = require('../utils/crud_service');

const crud = new crud_service();

//Create Admin
const createAdmin = asyncHandler(async (req, res) => {
  try {
    const data = {
      name: "Paul",
      companyname: "master",
      email: "master@gmail.com",
      phone: 7070707070,
      password: "123456",
      companycode: "kdsljfkjdskjfksdjfkldnsfjlndskfnsk",
    };
    for (i = 0; i < 400000; i++) {
      await crud.insertOne(admin, data, (err, result) => {});
    }
  } catch (err) {
    throw new Error(err);
  }
});

const createMany = asyncHandler(async (req, res) => {
  try {
    await crud.insertMany(admin, req.body, (err, result) => {
      if (err) {
        throw new Error(err);
      } else {
        success(res, 201, true, "Register Successfully", result);
      }
    });
  } catch (err) {
    throw new Error(err);
  }
});

const deleteOne = asyncHandler(async (req, res) => {
  try {
    await crud.deleteMany(admin, req.body, (err, result) => {
      if (err) {
        throw new Error(err);
      } else {
        success(res, 201, true, "Deleted Successfully", result);
      }
    });
  } catch (err) {
    throw new Error(err);
  }
});

const getOne = asyncHandler(async (req, res) => {
  try {
    await crud.getDocument(admin, {}, {}, { batchSize :5500,limit:50000}, (err, result) => {
      if (err) {
        throw new Error(err);
      } else {
        success(res, 201, true, "Get Data Successfully", result);
      }
    });
  } catch (err) {
    throw new Error(err);
  }
});




module.exports = {
  createAdmin,
  createMany,
  deleteOne,
  getOne,
};