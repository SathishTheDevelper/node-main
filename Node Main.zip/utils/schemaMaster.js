const mongoose = require('mongoose');
const version = { timestamps: true, versionKey: false };
//Import Schema
const import_admin_login_schema = require('../models/admin_login');
const import_master_settings_schema = require("../models/master_settings");





//Creating Schema
const create_admin_login_schema = mongoose.Schema(import_admin_login_schema, version);
const create_master_settings_schema = mongoose.Schema(import_master_settings_schema, version);




//Creating Model
const create_admin_login_model = mongoose.model('admin', create_admin_login_schema);
const create_master_settings_model = mongoose.model('master_settings', create_master_settings_schema);





module.exports = {
  admin: create_admin_login_model,
  mastersettings: create_master_settings_model,
};